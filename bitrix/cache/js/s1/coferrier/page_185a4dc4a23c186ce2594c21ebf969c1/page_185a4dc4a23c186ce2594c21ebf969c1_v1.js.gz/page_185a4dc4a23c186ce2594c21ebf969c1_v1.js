
; /* Start:"a:4:{s:4:"full";s:91:"/bitrix/components/bitrix/search.suggest.input/templates/.default/script.js?168313605112503";s:6:"source";s:75:"/bitrix/components/bitrix/search.suggest.input/templates/.default/script.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
function JsSuggest(oHandler, sParams, sParser)
{
	var t = this;

	t.oObj = oHandler;
	t.sParams = sParams;
	// Arrays for data
	if (sParser)
	{
		t.sExp = new RegExp("["+sParser+"]+", "i");
	}
	else
	{
		t.sExp = new RegExp(",");
	}
	t.oLast = {"str":false, "arr":false};
	t.oThis = {"str":false, "arr":false};
	t.oEl = {"start":false, "end":false};
	t.oUnfinedWords = {};
	// Flags
	t.bReady = true;
	t.eFocus = true;
	// Array with results & it`s showing
	t.aDiv = null;
	t.oDiv = null;
	// Pointers
	t.oActive = null;
	t.oPointer = [];
	t.oPointer_default = [];
	t.oPointer_this = 'input_field';

	t.oObj.onblur = function()
	{
		t.eFocus = false;
	};

	t.oObj.onfocus = function()
	{
		if (!t.eFocus)
		{
			t.eFocus = true;
			setTimeout(function(){t.CheckModif('focus')}, 500);
		}
	};

	t.oLast["arr"] = t.oObj.value.split(t.sExp);
	t.oLast["str"] = t.oLast["arr"].join(":");

	setTimeout(function(){t.CheckModif('this')}, 500);

	this.CheckModif = function(__data)
	{
		var
			sThis = false, tmp = 0,
			bUnfined = false, word = "",
			cursor = {};

		if (!t.eFocus)
			return;

		if (t.bReady && t.oObj.value.length > 0)
		{
			// Preparing input data
			t.oThis["arr"] = t.oObj.value.split(t.sExp);
			t.oThis["str"] = t.oThis["arr"].join(":");

			// Getting modificated element
			if (t.oThis["str"] && (t.oThis["str"] != t.oLast["str"]))
			{
				cursor['position'] = TCJsUtils.getCursorPosition(t.oObj);
				if (cursor['position']['end'] > 0 && !t.sExp.test(t.oObj.value.substr(cursor['position']['end']-1, 1)))
				{
					cursor['arr'] = t.oObj.value.substr(0, cursor['position']['end']).split(t.sExp);
					sThis = t.oThis["arr"][cursor['arr'].length - 1];

					t.oEl['start'] = cursor['position']['end'] - cursor['arr'][cursor['arr'].length - 1].length;
					t.oEl['end'] = t.oEl['start'] + sThis.length;
					t.oEl['content'] = sThis;

					t.oLast["arr"] = t.oThis["arr"];
					t.oLast["str"] = t.oThis["str"];
				}
			}
			if (sThis)
			{
				// Checking for UnfinedWords
				for (tmp = 2; tmp <= sThis.length; tmp++)
				{
					word = sThis.substr(0, tmp);
					if (t.oUnfinedWords[word] == '!fined')
					{
						bUnfined = true;
						break;
					}
				}
				if (!bUnfined)
					t.Send(sThis);
			}
		}
		setTimeout(function(){t.CheckModif('this')}, 500);
	};

	t.Send = function(sSearch)
	{
		if (!sSearch)
			return false;

		var oError = [];
		t.bReady = false;
		if (BX('wait_container'))
		{
			BX('wait_container').innerHTML = BX.message('JS_CORE_LOADING');
			BX.show(BX('wait_container'));
		}
		BX.ajax.post(
			'/bitrix/components/bitrix/search.suggest.input/search.php',
			{"search":sSearch, "params":t.sParams},
			function(data)
			{
				var result = {};
				t.bReady = true;

				try
				{
					eval("result = " + data + ";");
				}
				catch(e)
				{
					oError['result_unval'] = e;
				}

				if (TCJsUtils.empty(result))
					oError['result_empty'] = 'Empty result';

				try
				{
					if (TCJsUtils.empty(oError) && (typeof result == 'object'))
					{
						if (!(result.length == 1 && result[0]['NAME'] == t.oEl['content']))
						{
							t.Show(result);
							return;
						}
					}
					else
					{
						t.oUnfinedWords[t.oEl['content']] = '!fined';
					}
				}
				catch(e)
				{
					oError['unknown_error'] = e;
				}

				if(BX('wait_container'))
					BX.hide(BX('wait_container'));
			}
		);
	};

	t.Show = function(result)
	{
		t.Destroy();
		t.oDiv = document.body.appendChild(document.createElement("DIV"));
		t.oDiv.id = t.oObj.id+'_div';

		t.oDiv.className = "search-popup";
		t.oDiv.style.position = 'absolute';

		t.aDiv = t.Print(result);
		var pos = TCJsUtils.GetRealPos(t.oObj);
		t.oDiv.style.width = parseInt(pos["width"]) + "px";
		TCJsUtils.show(t.oDiv, pos["left"], pos["bottom"]);
		TCJsUtils.addEvent(document, "click", t.CheckMouse);
		TCJsUtils.addEvent(document, "keydown", t.CheckKeyword);
	};

	t.Print = function(aArr)
	{
		var aEl = null;
		var aResult = {};
		var iCnt = 0;
		var oDiv = null;
		var oSpan = null;
		var sPrefix = t.oDiv.id;

		for (var tmp_ in aArr)
		{
			if (aArr.hasOwnProperty(tmp_))
			{
				// Math
				aEl = aArr[tmp_];

				var aRes = {};
				aRes['ID'] = (aEl['ID'] && aEl['ID'].length > 0) ? aEl['ID'] : iCnt++;
				aRes['GID'] = sPrefix + '_' + aRes['ID'];
				aRes['NAME'] = TCJsUtils.htmlspecialcharsEx(aEl['NAME']);
				aRes['CNT'] = aEl['CNT'];

				aResult[aRes['GID']] = aRes;
				t.oPointer.push(aRes['GID']);
				// Graph
				oDiv = t.oDiv.appendChild(document.createElement("DIV"));
				oDiv.id = aRes['GID'];
				oDiv.name = sPrefix + '_div';

				oDiv.className = 'search-popup-row';

				oDiv.onmouseover = function(){t.Init(); this.className='search-popup-row-active';};
				oDiv.onmouseout = function(){t.Init(); this.className='search-popup-row';};
				oDiv.onclick = function(){t.oActive = this.id};

				oSpan = oDiv.appendChild(document.createElement("DIV"));
				oSpan.id = oDiv.id + '_NAME';
				oSpan.className = "search-popup-el search-popup-el-cnt";
				oSpan.innerHTML = aRes['CNT'];

				oSpan = oDiv.appendChild(document.createElement("DIV"));
				oSpan.id = oDiv.id + '_NAME';
				oSpan.className = "search-popup-el search-popup-el-name";
				oSpan.innerHTML = aRes['NAME'];
			}
		}
		t.oPointer.push('input_field');
		t.oPointer_default = t.oPointer;
		return aResult;
	};

	t.Destroy = function()
	{
		try
		{
			TCJsUtils.hide(t.oDiv);
			t.oDiv.parentNode.removeChild(t.oDiv);
		}
		catch(e)
		{}

		t.aDiv = [];
		t.oPointer = [];
		t.oPointer_default = [];
		t.oPointer_this = 'input_field';
		t.bReady = true;
		t.eFocus = true;
		t.oActive = null;

		TCJsUtils.removeEvent(document, "click", t.CheckMouse);
		TCJsUtils.removeEvent(document, "keydown", t.CheckKeyword);
	};

	t.Replace = function()
	{
		if (typeof t.oActive == 'string')
		{
			var tmp = t.aDiv[t.oActive];
			var tmp1 = '';
			if (typeof tmp == 'object')
			{
				var elEntities = document.createElement("span");
				elEntities.innerHTML = tmp['NAME'].replace(/&quot;/g, '"').replace(/&amp;/g, '&');
				tmp1 = elEntities.innerHTML;
			}
			//this preserves leading spaces
			var start = t.oEl['start'];
			while(start < t.oObj.value.length && t.oObj.value.substring(start, start+1) == " ")
				start++;

			t.oObj.value = t.oObj.value.substring(0, start) + tmp1.replace(/&lt;/g, '<').replace(/&gt;/g, '>') + t.oObj.value.substr(t.oEl['end']);
			TCJsUtils.setCursorPosition(t.oObj, start + tmp1.length);
		}
	};

	t.Init = function()
	{
		t.oActive = false;
		t.oPointer = t.oPointer_default;
		t.Clear();
		t.oPointer_this = 'input_pointer';
	};

	t.Clear = function()
	{
		var oEl = t.oDiv.getElementsByTagName("div");
		if (oEl.length > 0 && typeof oEl == 'object')
		{
			for (var ii in oEl)
			{
				if (oEl.hasOwnProperty(ii))
				{
					var oE = oEl[ii];
					if (oE && (typeof oE == 'object') && (oE.name == t.oDiv.id + '_div'))
					{
						oE.className = "search-popup-row";
					}
				}
			}
		}
	};

	t.CheckMouse = function()
	{
		t.Replace();
		t.Destroy();
	};

	t.CheckKeyword = function(e)
	{
		if (!e)
			e = window.event;

		var oP = null;
		var oEl = null;

		if ((37 < e.keyCode && e.keyCode <41) || (e.keyCode == 13))
		{
			t.Clear();

			switch (e.keyCode)
			{
				case 38:
					oP = t.oPointer.pop();
					if (t.oPointer_this == oP)
					{
						t.oPointer.unshift(oP);
						oP = t.oPointer.pop();
					}

					if (oP != 'input_field')
					{
						t.oActive = oP;
						oEl = document.getElementById(oP);
						if (typeof oEl == 'object')
						{
							oEl.className = "search-popup-row-active";
						}
					}
					t.oPointer.unshift(oP);
					break;
				case 40:
					oP = t.oPointer.shift();
					if (t.oPointer_this == oP)
					{
						t.oPointer.push(oP);
						oP = t.oPointer.shift();
					}
					if (oP != 'input_field')
					{
						t.oActive = oP;
						oEl = document.getElementById(oP);
						if (typeof oEl == 'object')
						{
							oEl.className = "search-popup-row-active";
						}
					}
					t.oPointer.push(oP);
					break;
				case 39:
					t.Replace();
					t.Destroy();
					break;
				case 13:
					t.Replace();
					t.Destroy();
					break;
			}
			t.oPointer_this = oP;
		}
		else
		{
			t.Destroy();
		}
	};
}

var TCJsUtils =
{
	arEvents: [],

	addEvent: function(el, evname, func)
	{
		if(el.attachEvent) // IE
			el.attachEvent("on" + evname, func);
		else if(el.addEventListener) // Gecko / W3C
			el.addEventListener(evname, func, false);
		else
			el["on" + evname] = func;
		this.arEvents[this.arEvents.length] = {'element': el, 'event': evname, 'fn': func};
	},

	removeEvent: function(el, evname, func)
	{
		if(el.detachEvent) // IE
			el.detachEvent("on" + evname, func);
		else if(el.removeEventListener) // Gecko / W3C
			el.removeEventListener(evname, func, false);
		else
			el["on" + evname] = null;
	},

	getCursorPosition: function(oObj)
	{
		var result = {'start': 0, 'end': 0};
		if (!oObj || (typeof oObj != 'object'))
			return result;
		try
		{
			if (document.selection != null && oObj.selectionStart == null)
			{
				oObj.focus();
				var oRange = document.selection.createRange();
				var oParent = oRange.parentElement();
				var sBookmark = oRange.getBookmark();
				var sContents = oObj.value;
				var sContents_ = oObj.value;
				var sMarker = '__' + Math.random() + '__';

				while(sContents.indexOf(sMarker) != -1)
				{
					sMarker = '__' + Math.random() + '__';
				}

				if (!oParent || oParent == null || (oParent.type != "textarea" && oParent.type != "text"))
				{
					return result;
				}

				oRange.text = sMarker + oRange.text + sMarker;
				sContents = oObj.value;
				result['start'] = sContents.indexOf(sMarker);
				sContents = sContents.replace(sMarker, "");
				result['end'] = sContents.indexOf(sMarker);
				oObj.value = sContents_;
				oRange.moveToBookmark(sBookmark);
				oRange.select();
				return result;
			}
			else
			{
				return {
					'start': oObj.selectionStart,
					'end': oObj.selectionEnd
				};
			}
		}
		catch(e){}
		return result;
	},

	setCursorPosition: function(oObj, iPosition)
	{
		if (typeof oObj != 'object')
			return false;

		oObj.focus();

		try
		{
			if (document.selection != null && oObj.selectionStart == null)
			{
				var oRange = document.selection.createRange();
				oRange.select();
			}
			else
			{
				oObj.selectionStart = iPosition;
				oObj.selectionEnd = iPosition;
			}
			return true;
		}
		catch(e)
		{
			return false;
		}

	},

	printArray: function (oObj, sParser, iLevel)
	{
		try
		{
			var result = '';
			var space = '';

			if (iLevel==undefined)
				iLevel = 0;
			if (!sParser)
				sParser = "\n";

			for (var j = 0; j <= iLevel; j++)
				space += '  ';

			for (var i in oObj)
			{
				if (oObj.hasOwnProperty(i))
				{
					if (typeof oObj[i] == 'object')
						result += space+i + " = {"+ sParser + TCJsUtils.printArray(oObj[i], sParser, iLevel+1) + ", " + sParser + "}" + sParser;
					else
						result += space+i + " = " + oObj[i] + "; " + sParser;
				}
			}

			return result;
		}
		catch(e)
		{
		}
	},

	empty: function(oObj)
	{
		var result = true;
		if (oObj)
		{
			for (var i in oObj)
			{
				if (oObj.hasOwnProperty(i))
				{
					result = false;
					break;
				}
			}
		}
		return result;
	},

	show: function(oDiv, iLeft, iTop)
	{
		if (typeof oDiv != 'object')
			return;
		var zIndex = parseInt(oDiv.style.zIndex);
		if(zIndex <= 0 || isNaN(zIndex))
			zIndex = 100;
		oDiv.style.zIndex = zIndex;
		oDiv.style.left = iLeft + "px";
		oDiv.style.top = iTop + "px";

		return oDiv;
	},

	hide: function(oDiv)
	{
		if(oDiv)
			oDiv.style.display = 'none';
	},

	GetRealPos: function(el)
	{
		if(!el || !el.offsetParent)
			return false;

		var res = {};
		var objParent = el.offsetParent;
		res["left"] = el.offsetLeft;
		res["top"] = el.offsetTop;
		while(objParent && objParent.tagName != "BODY")
		{
			res["left"] += objParent.offsetLeft;
			res["top"] += objParent.offsetTop;
			objParent = objParent.offsetParent;
		}
		res["right"]=res["left"] + el.offsetWidth;
		res["bottom"]=res["top"] + el.offsetHeight;
		res["width"]=el.offsetWidth;
		res["height"]=el.offsetHeight;

		return res;
	},

	htmlspecialcharsEx: function(str)
	{
		return str.replace(/&amp;/g, '&amp;amp;').replace(/&lt;/g, '&amp;lt;').replace(/&gt;/g, '&amp;gt;').replace(/&quot;/g, '&amp;quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
	},

	htmlspecialcharsback: function(str)
	{
		return str.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&amp;/g, '&');
	}
};

/* End */
;
; /* Start:"a:4:{s:4:"full";s:98:"/local/templates/coferrier/components/bitrix/catalog.section/.default/script.min.js?16871840335521";s:6:"source";s:79:"/local/templates/coferrier/components/bitrix/catalog.section/.default/script.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
(function(){if(!!window.JCCatalogSectionComponent){return}window.JCCatalogSectionComponent=function(a){this.formPosting=false;this.siteId=a.siteId||"";this.ajaxId=a.ajaxId||"";this.template=a.template||"";this.componentPath=a.componentPath||"";this.parameters=a.parameters||"";if(a.navParams){this.navParams={NavNum:a.navParams.NavNum||1,NavPageNomer:parseInt(a.navParams.NavPageNomer)||1,NavPageCount:parseInt(a.navParams.NavPageCount)||1}}this.bigData=a.bigData||{enabled:false};this.container=document.querySelector('[data-entity="'+a.container+'"]');this.showMoreButton=null;this.showMoreButtonMessage=null;if(this.bigData.enabled&&BX.util.object_keys(this.bigData.rows).length>0){BX.cookie_prefix=this.bigData.js.cookiePrefix||"";BX.cookie_domain=this.bigData.js.cookieDomain||"";BX.current_server_time=this.bigData.js.serverTime;BX.ready(BX.delegate(this.bigDataLoad,this))}if(a.initiallyShowHeader){BX.ready(BX.delegate(this.showHeader,this))}if(a.deferredLoad){BX.ready(BX.delegate(this.deferredLoad,this))}if(a.lazyLoad){this.showMoreButton=document.querySelector('[data-use="show-more-'+this.navParams.NavNum+'"]');this.showMoreButtonMessage=this.showMoreButton.innerHTML;BX.bind(this.showMoreButton,"click",BX.proxy(this.showMore,this))}if(a.loadOnScroll){BX.bind(window,"scroll",BX.proxy(this.loadOnScroll,this))}};window.JCCatalogSectionComponent.prototype={checkButton:function(){if(this.showMoreButton){if(this.navParams.NavPageNomer==this.navParams.NavPageCount){BX.remove(this.showMoreButton)}else{this.container.appendChild(this.showMoreButton)}}},enableButton:function(){if(this.showMoreButton){BX.removeClass(this.showMoreButton,"disabled");this.showMoreButton.innerHTML=this.showMoreButtonMessage}},disableButton:function(){if(this.showMoreButton){BX.addClass(this.showMoreButton,"disabled");this.showMoreButton.innerHTML=BX.message("BTN_MESSAGE_LAZY_LOAD_WAITER")}},loadOnScroll:function(){var b=BX.GetWindowScrollPos().scrollTop,a=BX.pos(this.container).bottom;if(b+window.innerHeight>a){this.showMore()}},showMore:function(){if(this.navParams.NavPageNomer<this.navParams.NavPageCount){var a={};a.action="showMore";a["PAGEN_"+this.navParams.NavNum]=this.navParams.NavPageNomer+1;if(!this.formPosting){this.formPosting=true;this.disableButton();this.sendRequest(a)}}},bigDataLoad:function(){var a="https://analytics.bitrix.info/crecoms/v1_0/recoms.php",b=BX.ajax.prepareData(this.bigData.params);if(b){a+=(a.indexOf("?")!==-1?"&":"?")+b}var c=BX.delegate(function(d){this.sendRequest({action:"deferredLoad",bigData:"Y",items:d&&d.items||[],rid:d&&d.id,count:this.bigData.count,rowsRange:this.bigData.rowsRange,shownIds:this.bigData.shownIds})},this);BX.ajax({method:"GET",dataType:"json",url:a,timeout:3,onsuccess:c,onfailure:c})},deferredLoad:function(){this.sendRequest({action:"deferredLoad"})},sendRequest:function(b){var a={siteId:this.siteId,template:this.template,parameters:this.parameters};if(this.ajaxId){a.AJAX_ID=this.ajaxId}BX.ajax({url:this.componentPath+"/ajax.php"+(document.location.href.indexOf("clear_cache=Y")!==-1?"?clear_cache=Y":""),method:"POST",dataType:"json",timeout:60,data:BX.merge(a,b),onsuccess:BX.delegate(function(c){if(!c||!c.JS){return}BX.ajax.processScripts(BX.processHTML(c.JS).SCRIPT,false,BX.delegate(function(){this.showAction(c,b)},this))},this)})},showAction:function(a,b){if(!b){return}switch(b.action){case"showMore":this.processShowMoreAction(a);break;case"deferredLoad":this.processDeferredLoadAction(a,b.bigData==="Y");break}},processShowMoreAction:function(a){this.formPosting=false;this.enableButton();if(a){this.navParams.NavPageNomer++;this.processItems(a.items);this.processPagination(a.pagination);this.processEpilogue(a.epilogue);this.checkButton()}},processDeferredLoadAction:function(b,c){if(!b){return}var a=c?this.bigData.rows:{};this.processItems(b.items,BX.util.array_keys(a))},processItems:function(f,a){if(!f){return}var g=BX.processHTML(f,false),d=BX.create("DIV");var c,b,e;d.innerHTML=g.HTML;c=d.querySelectorAll('[data-entity="items-row"]');if(c.length){this.showHeader(true);for(b in c){if(c.hasOwnProperty(b)){e=a?this.container.querySelectorAll('[data-entity="items-row"]'):false;c[b].style.opacity=0;if(e&&BX.type.isDomNode(e[a[b]])){e[a[b]].parentNode.insertBefore(c[b],e[a[b]])}else{this.container.appendChild(c[b])}}}new BX.easing({duration:2000,start:{opacity:0},finish:{opacity:100},transition:BX.easing.makeEaseOut(BX.easing.transitions.quad),step:function(i){for(var h in c){if(c.hasOwnProperty(h)){c[h].style.opacity=i.opacity/100}}},complete:function(){for(var h in c){if(c.hasOwnProperty(h)){c[h].removeAttribute("style")}}}}).animate()}BX.ajax.processScripts(g.SCRIPT)},processPagination:function(c){if(!c){return}var a=document.querySelectorAll('[data-pagination-num="'+this.navParams.NavNum+'"]');for(var b in a){if(a.hasOwnProperty(b)){a[b].innerHTML=c}}},processEpilogue:function(a){if(!a){return}var b=BX.processHTML(a,false);BX.ajax.processScripts(b.SCRIPT)},showHeader:function(b){var a=BX.findParent(this.container,{attr:{"data-entity":"parent-container"}}),c;if(a&&BX.type.isDomNode(a)){c=a.querySelector('[data-entity="header"]');if(c&&c.getAttribute("data-showed")!="true"){c.style.display="";if(b){new BX.easing({duration:2000,start:{opacity:0},finish:{opacity:100},transition:BX.easing.makeEaseOut(BX.easing.transitions.quad),step:function(d){c.style.opacity=d.opacity/100},complete:function(){c.removeAttribute("style");c.setAttribute("data-showed","true")}}).animate()}else{c.style.opacity=100}}}}}})();
/* End */
;
; /* Start:"a:4:{s:4:"full";s:92:"/local/templates/coferrier/components/bitrix/catalog.item/item/script.min.js?168733976741278";s:6:"source";s:72:"/local/templates/coferrier/components/bitrix/catalog.item/item/script.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
(function(b){if(b.JCCatalogItem){return}var a=function(c){a.superclass.constructor.apply(this,arguments);this.buttonNode=BX.create("button",{props:{className:"btn btn-primary btn-buy btn-sm",id:this.id},style:typeof c.style==="object"?c.style:{},text:c.text,events:this.contextEvents});if(BX.browser.IsIE()){this.buttonNode.setAttribute("hideFocus","hidefocus")}};BX.extend(a,BX.PopupWindowButton);b.JCCatalogItem=function(c){this.productType=0;this.showQuantity=true;this.showAbsent=true;this.secondPict=false;this.showOldPrice=false;this.showMaxQuantity="N";this.relativeQuantityFactor=5;this.showPercent=false;this.showSkuProps=false;this.basketAction="ADD";this.showClosePopup=false;this.useCompare=false;this.showSubscription=false;this.visual={ID:"",PICT_ID:"",SECOND_PICT_ID:"",PICT_SLIDER_ID:"",QUANTITY_ID:"",QUANTITY_UP_ID:"",QUANTITY_DOWN_ID:"",PRICE_ID:"",PRICE_OLD_ID:"",DSC_PERC:"",SECOND_DSC_PERC:"",DISPLAY_PROP_DIV:"",BASKET_PROP_DIV:"",SUBSCRIBE_ID:""};this.product={checkQuantity:false,maxQuantity:0,stepQuantity:1,isDblQuantity:false,canBuy:true,name:"",pict:{},id:0,addUrl:"",buyUrl:""};this.basketMode="";this.basketData={useProps:false,emptyProps:false,quantity:"quantity",props:"prop",basketUrl:"",sku_props:"",sku_props_var:"basket_props",add_url:"",buy_url:""};this.compareData={compareUrl:"",compareDeleteUrl:"",comparePath:""};this.defaultPict={pict:null,secondPict:null};this.defaultSliderOptions={interval:3000,wrap:true};this.slider={options:{},items:[],active:null,sliding:null,paused:null,interval:null,progress:null};this.touch=null;this.quantityDelay=null;this.quantityTimer=null;this.checkQuantity=false;this.maxQuantity=0;this.minQuantity=0;this.stepQuantity=1;this.isDblQuantity=false;this.canBuy=true;this.precision=6;this.precisionFactor=Math.pow(10,this.precision);this.bigData=false;this.fullDisplayMode=false;this.viewMode="";this.templateTheme="";this.currentPriceMode="";this.currentPrices=[];this.currentPriceSelected=0;this.currentQuantityRanges=[];this.currentQuantityRangeSelected=0;this.offers=[];this.offerNum=0;this.treeProps=[];this.selectedValues={};this.obProduct=null;this.blockNodes={};this.obQuantity=null;this.obQuantityUp=null;this.obQuantityDown=null;this.obQuantityLimit={};this.obPict=null;this.obSecondPict=null;this.obPictSlider=null;this.obPictSliderIndicator=null;this.obPrice=null;this.obTree=null;this.obBuyBtn=null;this.obBasketActions=null;this.obNotAvail=null;this.obSubscribe=null;this.obDscPerc=null;this.obSecondDscPerc=null;this.obSkuProps=null;this.obMeasure=null;this.obCompare=null;this.obPopupWin=null;this.basketUrl="";this.basketParams={};this.isTouchDevice=BX.hasClass(document.documentElement,"bx-touch");this.hoverTimer=null;this.hoverStateChangeForbidden=false;this.mouseX=null;this.mouseY=null;this.useEnhancedEcommerce=false;this.dataLayerName="dataLayer";this.brandProperty=false;this.errorCode=0;if(typeof c==="object"){if(c.PRODUCT_TYPE){this.productType=parseInt(c.PRODUCT_TYPE,10)}this.showQuantity=c.SHOW_QUANTITY;this.showAbsent=c.SHOW_ABSENT;this.secondPict=c.SECOND_PICT;this.showOldPrice=c.SHOW_OLD_PRICE;this.showMaxQuantity=c.SHOW_MAX_QUANTITY;this.relativeQuantityFactor=parseInt(c.RELATIVE_QUANTITY_FACTOR);this.showPercent=c.SHOW_DISCOUNT_PERCENT;this.showSkuProps=c.SHOW_SKU_PROPS;this.showSubscription=c.USE_SUBSCRIBE;if(c.ADD_TO_BASKET_ACTION){this.basketAction=c.ADD_TO_BASKET_ACTION}this.showClosePopup=c.SHOW_CLOSE_POPUP;this.useCompare=c.DISPLAY_COMPARE;this.fullDisplayMode=c.PRODUCT_DISPLAY_MODE==="Y";this.bigData=c.BIG_DATA;this.viewMode=c.VIEW_MODE||"";this.templateTheme=c.TEMPLATE_THEME||"";this.useEnhancedEcommerce=c.USE_ENHANCED_ECOMMERCE==="Y";this.dataLayerName=c.DATA_LAYER_NAME;this.brandProperty=c.BRAND_PROPERTY;this.visual=c.VISUAL;switch(this.productType){case 0:case 1:case 2:if(c.PRODUCT&&typeof c.PRODUCT==="object"){this.currentPriceMode=c.PRODUCT.ITEM_PRICE_MODE;this.currentPrices=c.PRODUCT.ITEM_PRICES;this.currentPriceSelected=c.PRODUCT.ITEM_PRICE_SELECTED;this.currentQuantityRanges=c.PRODUCT.ITEM_QUANTITY_RANGES;this.currentQuantityRangeSelected=c.PRODUCT.ITEM_QUANTITY_RANGE_SELECTED;if(this.showQuantity){this.product.checkQuantity=c.PRODUCT.CHECK_QUANTITY;this.product.isDblQuantity=c.PRODUCT.QUANTITY_FLOAT;if(this.product.checkQuantity){this.product.maxQuantity=(this.product.isDblQuantity?parseFloat(c.PRODUCT.MAX_QUANTITY):parseInt(c.PRODUCT.MAX_QUANTITY,10))}this.product.stepQuantity=(this.product.isDblQuantity?parseFloat(c.PRODUCT.STEP_QUANTITY):parseInt(c.PRODUCT.STEP_QUANTITY,10));this.checkQuantity=this.product.checkQuantity;this.isDblQuantity=this.product.isDblQuantity;this.stepQuantity=this.product.stepQuantity;this.maxQuantity=this.product.maxQuantity;this.minQuantity=this.currentPriceMode==="Q"?parseFloat(this.currentPrices[this.currentPriceSelected].MIN_QUANTITY):this.stepQuantity;if(this.isDblQuantity){this.stepQuantity=Math.round(this.stepQuantity*this.precisionFactor)/this.precisionFactor}}this.product.canBuy=c.PRODUCT.CAN_BUY;if(c.PRODUCT.MORE_PHOTO_COUNT){this.product.morePhotoCount=c.PRODUCT.MORE_PHOTO_COUNT;this.product.morePhoto=c.PRODUCT.MORE_PHOTO}if(c.PRODUCT.RCM_ID){this.product.rcmId=c.PRODUCT.RCM_ID}this.canBuy=this.product.canBuy;this.product.name=c.PRODUCT.NAME;this.product.pict=c.PRODUCT.PICT;this.product.id=c.PRODUCT.ID;this.product.DETAIL_PAGE_URL=c.PRODUCT.DETAIL_PAGE_URL;if(c.PRODUCT.ADD_URL){this.product.addUrl=c.PRODUCT.ADD_URL}if(c.PRODUCT.BUY_URL){this.product.buyUrl=c.PRODUCT.BUY_URL}if(c.BASKET&&typeof c.BASKET==="object"){this.basketData.useProps=c.BASKET.ADD_PROPS;this.basketData.emptyProps=c.BASKET.EMPTY_PROPS}}else{this.errorCode=-1}break;case 3:if(c.PRODUCT&&typeof c.PRODUCT==="object"){this.product.name=c.PRODUCT.NAME;this.product.id=c.PRODUCT.ID;this.product.DETAIL_PAGE_URL=c.PRODUCT.DETAIL_PAGE_URL;this.product.morePhotoCount=c.PRODUCT.MORE_PHOTO_COUNT;this.product.morePhoto=c.PRODUCT.MORE_PHOTO;if(c.PRODUCT.RCM_ID){this.product.rcmId=c.PRODUCT.RCM_ID}}if(c.OFFERS&&BX.type.isArray(c.OFFERS)){this.offers=c.OFFERS;this.offerNum=0;if(c.OFFER_SELECTED){this.offerNum=parseInt(c.OFFER_SELECTED,10)}if(isNaN(this.offerNum)){this.offerNum=0}if(c.TREE_PROPS){this.treeProps=c.TREE_PROPS}if(c.DEFAULT_PICTURE){this.defaultPict.pict=c.DEFAULT_PICTURE.PICTURE;this.defaultPict.secondPict=c.DEFAULT_PICTURE.PICTURE_SECOND}}break;default:this.errorCode=-1}if(c.BASKET&&typeof c.BASKET==="object"){if(c.BASKET.QUANTITY){this.basketData.quantity=c.BASKET.QUANTITY}if(c.BASKET.PROPS){this.basketData.props=c.BASKET.PROPS}if(c.BASKET.BASKET_URL){this.basketData.basketUrl=c.BASKET.BASKET_URL}if(3===this.productType){if(c.BASKET.SKU_PROPS){this.basketData.sku_props=c.BASKET.SKU_PROPS}}if(c.BASKET.ADD_URL_TEMPLATE){this.basketData.add_url=c.BASKET.ADD_URL_TEMPLATE}if(c.BASKET.BUY_URL_TEMPLATE){this.basketData.buy_url=c.BASKET.BUY_URL_TEMPLATE}if(this.basketData.add_url===""&&this.basketData.buy_url===""){this.errorCode=-1024}}if(this.useCompare){if(c.COMPARE&&typeof c.COMPARE==="object"){if(c.COMPARE.COMPARE_PATH){this.compareData.comparePath=c.COMPARE.COMPARE_PATH}if(c.COMPARE.COMPARE_URL_TEMPLATE){this.compareData.compareUrl=c.COMPARE.COMPARE_URL_TEMPLATE}else{this.useCompare=false}if(c.COMPARE.COMPARE_DELETE_URL_TEMPLATE){this.compareData.compareDeleteUrl=c.COMPARE.COMPARE_DELETE_URL_TEMPLATE}else{this.useCompare=false}}else{this.useCompare=false}}this.isFacebookConversionCustomizeProductEventEnabled=c.IS_FACEBOOK_CONVERSION_CUSTOMIZE_PRODUCT_EVENT_ENABLED}if(this.errorCode===0){BX.ready(BX.delegate(this.init,this))}};b.JCCatalogItem.prototype={init:function(){var d=0,g=null;this.obProduct=BX(this.visual.ID);if(!this.obProduct){this.errorCode=-1}this.obPict=BX(this.visual.PICT_ID);if(!this.obPict){this.errorCode=-2}if(this.secondPict&&this.visual.SECOND_PICT_ID){this.obSecondPict=BX(this.visual.SECOND_PICT_ID)}this.obPictSlider=BX(this.visual.PICT_SLIDER_ID);this.obPictSliderIndicator=BX(this.visual.PICT_SLIDER_ID+"_indicator");this.obPictSliderProgressBar=BX(this.visual.PICT_SLIDER_ID+"_progress_bar");if(!this.obPictSlider){this.errorCode=-4}this.obPrice=BX(this.visual.PRICE_ID);this.obPriceOld=BX(this.visual.PRICE_OLD_ID);this.obPriceTotal=BX(this.visual.PRICE_TOTAL_ID);if(!this.obPrice){this.errorCode=-16}if(this.showQuantity&&this.visual.QUANTITY_ID){this.obQuantity=BX(this.visual.QUANTITY_ID);this.blockNodes.quantity=this.obProduct.querySelector('[data-entity="quantity-block"]');if(!this.isTouchDevice){BX.bind(this.obQuantity,"focus",BX.proxy(this.onFocus,this));BX.bind(this.obQuantity,"blur",BX.proxy(this.onBlur,this))}if(this.visual.QUANTITY_UP_ID){this.obQuantityUp=BX(this.visual.QUANTITY_UP_ID)}if(this.visual.QUANTITY_DOWN_ID){this.obQuantityDown=BX(this.visual.QUANTITY_DOWN_ID)}}if(this.visual.QUANTITY_LIMIT&&this.showMaxQuantity!=="N"){this.obQuantityLimit.all=BX(this.visual.QUANTITY_LIMIT);if(this.obQuantityLimit.all){this.obQuantityLimit.value=this.obQuantityLimit.all.querySelector('[data-entity="quantity-limit-value"]');if(!this.obQuantityLimit.value){this.obQuantityLimit.all=null}}}if(this.productType===3&&this.fullDisplayMode){if(this.visual.TREE_ID){this.obTree=BX(this.visual.TREE_ID);if(!this.obTree){this.errorCode=-256}}if(this.visual.QUANTITY_MEASURE){this.obMeasure=BX(this.visual.QUANTITY_MEASURE)}}this.obBasketActions=BX(this.visual.BASKET_ACTIONS_ID);if(this.obBasketActions){if(this.visual.BUY_ID){this.obBuyBtn=BX(this.visual.BUY_ID)}}this.obNotAvail=BX(this.visual.NOT_AVAILABLE_MESS);if(this.showSubscription){this.obSubscribe=BX(this.visual.SUBSCRIBE_ID)}if(this.showPercent){if(this.visual.DSC_PERC){this.obDscPerc=BX(this.visual.DSC_PERC)}if(this.secondPict&&this.visual.SECOND_DSC_PERC){this.obSecondDscPerc=BX(this.visual.SECOND_DSC_PERC)}}if(this.showSkuProps){if(this.visual.DISPLAY_PROP_DIV){this.obSkuProps=BX(this.visual.DISPLAY_PROP_DIV)}}if(this.errorCode===0){if(this.isTouchDevice){BX.bind(this.obPictSlider,"touchstart",BX.proxy(this.touchStartEvent,this));BX.bind(this.obPictSlider,"touchend",BX.proxy(this.touchEndEvent,this));BX.bind(this.obPictSlider,"touchcancel",BX.proxy(this.touchEndEvent,this))}else{if(this.viewMode==="CARD"){BX.bind(this.obProduct,"mouseenter",BX.proxy(this.hoverOn,this));BX.bind(this.obProduct,"mouseleave",BX.proxy(this.hoverOff,this))}BX.bind(this.obProduct,"mouseenter",BX.proxy(this.cycleSlider,this));BX.bind(this.obProduct,"mouseleave",BX.proxy(this.stopSlider,this))}if(this.bigData){var c=BX.findChildren(this.obProduct,{tag:"a"},true);if(c){for(d in c){if(c.hasOwnProperty(d)){if(c[d].getAttribute("href")==this.product.DETAIL_PAGE_URL){BX.bind(c[d],"click",BX.proxy(this.rememberProductRecommendation,this))}}}}}if(this.showQuantity){var e=this.isTouchDevice?"touchstart":"mousedown";var f=this.isTouchDevice?"touchend":"mouseup";if(this.obQuantityUp){BX.bind(this.obQuantityUp,e,BX.proxy(this.startQuantityInterval,this));BX.bind(this.obQuantityUp,f,BX.proxy(this.clearQuantityInterval,this));BX.bind(this.obQuantityUp,"mouseout",BX.proxy(this.clearQuantityInterval,this));BX.bind(this.obQuantityUp,"click",BX.delegate(this.quantityUp,this))}if(this.obQuantityDown){BX.bind(this.obQuantityDown,e,BX.proxy(this.startQuantityInterval,this));BX.bind(this.obQuantityDown,f,BX.proxy(this.clearQuantityInterval,this));BX.bind(this.obQuantityDown,"mouseout",BX.proxy(this.clearQuantityInterval,this));BX.bind(this.obQuantityDown,"click",BX.delegate(this.quantityDown,this))}if(this.obQuantity){BX.bind(this.obQuantity,"change",BX.delegate(this.quantityChange,this))}}switch(this.productType){case 0:case 1:case 2:if(parseInt(this.product.morePhotoCount)>1&&this.obPictSlider){this.initializeSlider()}this.checkQuantityControls();break;case 3:if(this.offers.length>0){g=BX.findChildren(this.obTree,{tagName:"li"},true);if(g&&g.length){for(d=0;d<g.length;d++){BX.bind(g[d],"click",BX.delegate(this.selectOfferProp,this))}}this.setCurrent()}else{if(parseInt(this.product.morePhotoCount)>1&&this.obPictSlider){this.initializeSlider()}}break}if(this.obBuyBtn){if(this.basketAction==="ADD"){BX.bind(this.obBuyBtn,"click",BX.proxy(this.add2Basket,this))}else{BX.bind(this.obBuyBtn,"click",BX.proxy(this.buyBasket,this))}}if(this.useCompare){this.obCompare=BX(this.visual.COMPARE_LINK_ID);if(this.obCompare){BX.bind(this.obCompare,"click",BX.proxy(this.compare,this))}BX.addCustomEvent("onCatalogDeleteCompare",BX.proxy(this.checkDeletedCompare,this))}}},setAnalyticsDataLayer:function(f){if(!this.useEnhancedEcommerce||!this.dataLayerName){return}var o={},d={},m=[],l,g,h,c,n,e;switch(this.productType){case 0:case 1:case 2:o={id:this.product.id,name:this.product.name,price:this.currentPrices[this.currentPriceSelected]&&this.currentPrices[this.currentPriceSelected].PRICE,brand:BX.type.isArray(this.brandProperty)?this.brandProperty.join("/"):this.brandProperty};break;case 3:for(l in this.offers[this.offerNum].TREE){if(this.offers[this.offerNum].TREE.hasOwnProperty(l)){c=l.substring(5);n=this.offers[this.offerNum].TREE[l];for(g in this.treeProps){if(this.treeProps.hasOwnProperty(g)&&this.treeProps[g].ID==c){for(h in this.treeProps[g].VALUES){e=this.treeProps[g].VALUES[h];if(e.ID==n){m.push(e.NAME);break}}}}}}o={id:this.offers[this.offerNum].ID,name:this.offers[this.offerNum].NAME,price:this.currentPrices[this.currentPriceSelected]&&this.currentPrices[this.currentPriceSelected].PRICE,brand:BX.type.isArray(this.brandProperty)?this.brandProperty.join("/"):this.brandProperty,variant:m.join("/")};break}switch(f){case"addToCart":d={ecommerce:{currencyCode:this.currentPrices[this.currentPriceSelected]&&this.currentPrices[this.currentPriceSelected].CURRENCY||"",add:{products:[{name:o.name||"",id:o.id||"",price:o.price||0,brand:o.brand||"",category:o.category||"",variant:o.variant||"",quantity:this.showQuantity&&this.obQuantity?this.obQuantity.value:1}]}}};break}b[this.dataLayerName]=b[this.dataLayerName]||[];b[this.dataLayerName].push(d)},hoverOn:function(c){clearTimeout(this.hoverTimer);this.obProduct.style.height=getComputedStyle(this.obProduct).height;BX.addClass(this.obProduct,"hover");BX.PreventDefault(c)},hoverOff:function(c){if(this.hoverStateChangeForbidden){return}BX.removeClass(this.obProduct,"hover");this.hoverTimer=setTimeout(BX.delegate(function(){this.obProduct.style.height="auto"},this),300);BX.PreventDefault(c)},onFocus:function(){this.hoverStateChangeForbidden=true;BX.bind(document,"mousemove",BX.proxy(this.captureMousePosition,this))},onBlur:function(){this.hoverStateChangeForbidden=false;BX.unbind(document,"mousemove",BX.proxy(this.captureMousePosition,this));var c=document.elementFromPoint(this.mouseX,this.mouseY);if(!c||!this.obProduct.contains(c)){this.hoverOff()}},captureMousePosition:function(c){this.mouseX=c.clientX;this.mouseY=c.clientY},getCookie:function(c){var d=document.cookie.match(new RegExp("(?:^|; )"+c.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g,"\\$1")+"=([^;]*)"));return d?decodeURIComponent(d[1]):null},rememberProductRecommendation:function(){var k=BX.cookie_prefix+"_RCM_PRODUCT_LOG",f=this.getCookie(k),g=false;var j=[],d;if(f){j=f.split(".")}var e=j.length;while(e--){d=j[e].split("-");if(d[0]==this.product.id){d=j[e].split("-");d[1]=this.product.rcmId;d[2]=BX.current_server_time;j[e]=d.join("-");g=true}else{if((BX.current_server_time-d[2])>3600*24*30){j.splice(e,1)}}}if(!g){j.push([this.product.id,this.product.rcmId,BX.current_server_time].join("-"))}var c=j.join("."),h=new Date(new Date().getTime()+1000*3600*24*365*10).toUTCString();document.cookie=k+"="+c+"; path=/; expires="+h+"; domain="+BX.cookie_domain},startQuantityInterval:function(){var d=BX.proxy_context;var c=d.id===this.visual.QUANTITY_DOWN_ID?BX.proxy(this.quantityDown,this):BX.proxy(this.quantityUp,this);this.quantityDelay=setTimeout(BX.delegate(function(){this.quantityTimer=setInterval(c,150)},this),300)},clearQuantityInterval:function(){clearTimeout(this.quantityDelay);clearInterval(this.quantityTimer)},quantityUp:function(){var d=0,c=true;if(this.errorCode===0&&this.showQuantity&&this.canBuy){d=(this.isDblQuantity?parseFloat(this.obQuantity.value):parseInt(this.obQuantity.value,10));if(!isNaN(d)){d+=this.stepQuantity;if(this.checkQuantity){if(d>this.maxQuantity){c=false}}if(c){if(this.isDblQuantity){d=Math.round(d*this.precisionFactor)/this.precisionFactor}this.obQuantity.value=d;this.setPrice()}}}},quantityDown:function(){var d=0,c=true;if(this.errorCode===0&&this.showQuantity&&this.canBuy){d=(this.isDblQuantity?parseFloat(this.obQuantity.value):parseInt(this.obQuantity.value,10));if(!isNaN(d)){d-=this.stepQuantity;this.checkPriceRange(d);if(d<this.minQuantity){c=false}if(c){if(this.isDblQuantity){d=Math.round(d*this.precisionFactor)/this.precisionFactor}this.obQuantity.value=d;this.setPrice()}}}},quantityChange:function(){var d=0,c;if(this.errorCode===0&&this.showQuantity){if(this.canBuy){d=this.isDblQuantity?parseFloat(this.obQuantity.value):Math.round(this.obQuantity.value);if(!isNaN(d)){if(this.checkQuantity){if(d>this.maxQuantity){d=this.maxQuantity}}this.checkPriceRange(d);c=Math.floor(Math.round(d*this.precisionFactor/this.stepQuantity)/this.precisionFactor)||1;d=(c<=1?this.stepQuantity:c*this.stepQuantity);d=Math.round(d*this.precisionFactor)/this.precisionFactor;if(d<this.minQuantity){d=this.minQuantity}this.obQuantity.value=d}else{this.obQuantity.value=this.minQuantity}}else{this.obQuantity.value=this.minQuantity}this.setPrice()}},quantitySet:function(f){var g,e;var h=this.offers[f],c=this.offers[this.offerNum];if(this.errorCode===0){this.canBuy=h.CAN_BUY;this.currentPriceMode=h.ITEM_PRICE_MODE;this.currentPrices=h.ITEM_PRICES;this.currentPriceSelected=h.ITEM_PRICE_SELECTED;this.currentQuantityRanges=h.ITEM_QUANTITY_RANGES;this.currentQuantityRangeSelected=h.ITEM_QUANTITY_RANGE_SELECTED;if(this.canBuy){if(this.blockNodes.quantity){BX.style(this.blockNodes.quantity,"display","")}if(this.obBasketActions){BX.style(this.obBasketActions,"display","")}if(this.obNotAvail){BX.style(this.obNotAvail,"display","none")}if(this.obSubscribe){BX.style(this.obSubscribe,"display","none")}}else{if(this.blockNodes.quantity){BX.style(this.blockNodes.quantity,"display","none")}if(this.obBasketActions){BX.style(this.obBasketActions,"display","none")}if(this.obNotAvail){BX.style(this.obNotAvail,"display","")}if(this.obSubscribe){if(h.CATALOG_SUBSCRIBE==="Y"){BX.style(this.obSubscribe,"display","");this.obSubscribe.setAttribute("data-item",h.ID);BX(this.visual.SUBSCRIBE_ID+"_hidden").click()}else{BX.style(this.obSubscribe,"display","none")}}}this.isDblQuantity=h.QUANTITY_FLOAT;this.checkQuantity=h.CHECK_QUANTITY;if(this.isDblQuantity){this.stepQuantity=Math.round(parseFloat(h.STEP_QUANTITY)*this.precisionFactor)/this.precisionFactor;this.maxQuantity=parseFloat(h.MAX_QUANTITY);this.minQuantity=this.currentPriceMode==="Q"?parseFloat(this.currentPrices[this.currentPriceSelected].MIN_QUANTITY):this.stepQuantity}else{this.stepQuantity=parseInt(h.STEP_QUANTITY,10);this.maxQuantity=parseInt(h.MAX_QUANTITY,10);this.minQuantity=this.currentPriceMode==="Q"?parseInt(this.currentPrices[this.currentPriceSelected].MIN_QUANTITY):this.stepQuantity}if(this.showQuantity){var d=c.ITEM_PRICES.length&&c.ITEM_PRICES[c.ITEM_PRICE_SELECTED]&&c.ITEM_PRICES[c.ITEM_PRICE_SELECTED].MIN_QUANTITY!=this.minQuantity;if(this.isDblQuantity){g=Math.round(parseFloat(c.STEP_QUANTITY)*this.precisionFactor)/this.precisionFactor!==this.stepQuantity||d||c.MEASURE!==h.MEASURE||(this.checkQuantity&&parseFloat(c.MAX_QUANTITY)>this.maxQuantity&&parseFloat(this.obQuantity.value)>this.maxQuantity)}else{g=parseInt(c.STEP_QUANTITY,10)!==this.stepQuantity||d||c.MEASURE!==h.MEASURE||(this.checkQuantity&&parseInt(c.MAX_QUANTITY,10)>this.maxQuantity&&parseInt(this.obQuantity.value,10)>this.maxQuantity)}this.obQuantity.disabled=!this.canBuy;if(g){this.obQuantity.value=this.minQuantity}if(this.obMeasure){if(h.MEASURE){BX.adjust(this.obMeasure,{html:h.MEASURE})}else{BX.adjust(this.obMeasure,{html:""})}}}if(this.obQuantityLimit.all){if(!this.checkQuantity||this.maxQuantity==0){BX.adjust(this.obQuantityLimit.value,{html:""});BX.adjust(this.obQuantityLimit.all,{style:{display:"none"}})}else{if(this.showMaxQuantity==="M"){e=(this.maxQuantity/this.stepQuantity>=this.relativeQuantityFactor)?BX.message("RELATIVE_QUANTITY_MANY"):BX.message("RELATIVE_QUANTITY_FEW")}else{e=this.maxQuantity;if(h.MEASURE){e+=(" "+h.MEASURE)}}BX.adjust(this.obQuantityLimit.value,{html:e});BX.adjust(this.obQuantityLimit.all,{style:{display:""}})}}}},initializeSlider:function(){var e=this.obPictSlider.getAttribute("data-slider-wrap");if(e){this.slider.options.wrap=e==="true"}else{this.slider.options.wrap=this.defaultSliderOptions.wrap}if(this.isTouchDevice){this.slider.options.interval=false}else{this.slider.options.interval=parseInt(this.obPictSlider.getAttribute("data-slider-interval"))||this.defaultSliderOptions.interval;if(this.slider.options.interval<700){this.slider.options.interval=700}if(this.obPictSliderIndicator){var c=this.obPictSliderIndicator.querySelectorAll("[data-go-to]");for(var d in c){if(c.hasOwnProperty(d)){BX.bind(c[d],"click",BX.proxy(this.sliderClickHandler,this))}}}if(this.obPictSliderProgressBar){if(this.slider.progress){this.resetProgress();this.cycleSlider()}else{this.slider.progress=new BX.easing({transition:BX.easing.transitions.linear,step:BX.delegate(function(f){this.obPictSliderProgressBar.style.width=f.width/10+"%"},this)})}}}},checkTouch:function(c){if(!c||!c.changedTouches){return false}return c.changedTouches[0].identifier===this.touch.identifier},touchStartEvent:function(c){if(c.touches.length!=1){return}this.touch=c.changedTouches[0]},touchEndEvent:function(e){if(!this.checkTouch(e)){return}var d=this.touch.pageX-e.changedTouches[0].pageX,c=this.touch.pageY-e.changedTouches[0].pageY;if(Math.abs(d)>=Math.abs(c)+10){if(d>0){this.slideNext()}if(d<0){this.slidePrev()}}},sliderClickHandler:function(c){var e=BX.getEventTarget(c),d=e.getAttribute("data-go-to");if(d){this.slideTo(d)}BX.PreventDefault(c)},slideNext:function(){if(this.slider.sliding){return}return this.slide("next")},slidePrev:function(){if(this.slider.sliding){return}return this.slide("prev")},slideTo:function(d){this.slider.active=BX.findChild(this.obPictSlider,{className:"item active"},true,false);this.slider.progress&&(this.slider.interval=true);var c=this.getItemIndex(this.slider.active);if(d>(this.slider.items.length-1)||d<0){return}if(this.slider.sliding){return false}if(c==d){this.stopSlider();this.cycleSlider();return}return this.slide(d>c?"next":"prev",this.eq(this.slider.items,d))},slide:function(f,e){var h=BX.findChild(this.obPictSlider,{className:"item active"},true,false),i=this.slider.interval,g=f==="next"?"left":"right";e=e||this.getItemForDirection(f,h);if(BX.hasClass(e,"active")){return(this.slider.sliding=false)}this.slider.sliding=true;i&&this.stopSlider();if(this.obPictSliderIndicator){BX.removeClass(this.obPictSliderIndicator.querySelector(".active"),"active");var c=this.obPictSliderIndicator.querySelectorAll("[data-go-to]")[this.getItemIndex(e)];c&&BX.addClass(c,"active")}if(BX.hasClass(this.obPictSlider,"slide")&&!BX.browser.IsIE()){var d=this;BX.addClass(e,f);e.offsetWidth;BX.addClass(h,g);BX.addClass(e,g);setTimeout(function(){BX.addClass(e,"active");BX.removeClass(h,"active");BX.removeClass(h,g);BX.removeClass(e,f);BX.removeClass(e,g);d.slider.sliding=false},700)}else{BX.addClass(e,"active");this.slider.sliding=false}this.obPictSliderProgressBar&&this.resetProgress();i&&this.cycleSlider()},stopSlider:function(d){d||(this.slider.paused=true);this.slider.interval&&clearInterval(this.slider.interval);if(this.slider.progress){this.slider.progress.stop();var c=parseInt(this.obPictSliderProgressBar.style.width);this.slider.progress.options.duration=this.slider.options.interval*c/200;this.slider.progress.options.start={width:c*10};this.slider.progress.options.finish={width:0};this.slider.progress.options.complete=null;this.slider.progress.animate()}},cycleSlider:function(d){d||(this.slider.paused=false);this.slider.interval&&clearInterval(this.slider.interval);if(this.slider.options.interval&&!this.slider.paused){if(this.slider.progress){this.slider.progress.stop();var c=parseInt(this.obPictSliderProgressBar.style.width);this.slider.progress.options.duration=this.slider.options.interval*(100-c)/100;this.slider.progress.options.start={width:c*10};this.slider.progress.options.finish={width:1000};this.slider.progress.options.complete=BX.delegate(function(){this.slider.interval=true;this.slideNext()},this);this.slider.progress.animate()}else{this.slider.interval=setInterval(BX.proxy(this.slideNext,this),this.slider.options.interval)}}},resetProgress:function(){this.slider.progress&&this.slider.progress.stop();this.obPictSliderProgressBar.style.width=0},getItemForDirection:function(g,f){var c=this.getItemIndex(f),d=g==="prev"&&c===0||g==="next"&&c==(this.slider.items.length-1);if(d&&!this.slider.options.wrap){return f}var h=g==="prev"?-1:1,e=(c+h)%this.slider.items.length;return this.eq(this.slider.items,e)},getItemIndex:function(c){this.slider.items=BX.findChildren(c.parentNode,{className:"item"},true);return this.slider.items.indexOf(c||this.slider.active)},eq:function(f,e){var c=f.length,d=+e+(e<0?c:0);return d>=0&&d<c?f[d]:{}},selectOfferProp:function(){var c=0,e="",d="",h=[],g=null,f=BX.proxy_context;if(f&&f.hasAttribute("data-treevalue")){if(BX.hasClass(f,"selected")){return}d=f.getAttribute("data-treevalue");h=d.split("_");if(this.searchOfferPropIndex(h[0],h[1])){g=BX.findChildren(f.parentNode,{tagName:"li"},false);if(g&&0<g.length){for(c=0;c<g.length;c++){e=g[c].getAttribute("data-onevalue");if(e===h[1]){BX.addClass(g[c],"selected")}else{BX.removeClass(g[c],"selected")}}}if(this.isFacebookConversionCustomizeProductEventEnabled&&BX.Type.isArrayFilled(this.offers)&&BX.Type.isObject(this.offers[this.offerNum])){BX.ajax.runAction("sale.facebookconversion.customizeProduct",{data:{offerId:this.offers[this.offerNum]["ID"]}})}}}},searchOfferPropIndex:function(e,n){var k="",o=false,f,d,l=[],c=[],g=-1,h={},m=[];for(f=0;f<this.treeProps.length;f++){if(this.treeProps[f].ID===e){g=f;break}}if(-1<g){for(f=0;f<g;f++){k="PROP_"+this.treeProps[f].ID;h[k]=this.selectedValues[k]}k="PROP_"+this.treeProps[g].ID;o=this.getRowValues(h,k);if(!o){return false}if(!BX.util.in_array(n,o)){return false}h[k]=n;for(f=g+1;f<this.treeProps.length;f++){k="PROP_"+this.treeProps[f].ID;o=this.getRowValues(h,k);if(!o){return false}c=[];if(this.showAbsent){l=[];m=[];m=BX.clone(h,true);for(d=0;d<o.length;d++){m[k]=o[d];c[c.length]=o[d];if(this.getCanBuy(m)){l[l.length]=o[d]}}}else{l=o}if(this.selectedValues[k]&&BX.util.in_array(this.selectedValues[k],l)){h[k]=this.selectedValues[k]}else{if(this.showAbsent){h[k]=(l.length>0?l[0]:c[0])}else{h[k]=l[0]}}this.updateRow(f,h[k],o,l)}this.selectedValues=h;this.changeInfo()}return true},updateRow:function(m,g,h,d){var e=0,k="",c=false,j=null;var l=this.obTree.querySelectorAll('[data-entity="sku-line-block"]'),f;if(m>-1&&m<l.length){f=l[m].querySelector("ul");j=BX.findChildren(f,{tagName:"li"},false);if(j&&0<j.length){for(e=0;e<j.length;e++){k=j[e].getAttribute("data-onevalue");c=k===g;if(c){BX.addClass(j[e],"selected")}else{BX.removeClass(j[e],"selected")}if(BX.util.in_array(k,d)){BX.removeClass(j[e],"notallowed")}else{BX.addClass(j[e],"notallowed")}j[e].style.display=BX.util.in_array(k,h)?"":"none";if(c){l[m].style.display=(k==0&&d.length==1)?"none":""}}}}},getRowValues:function(d,f){var g=0,e,c=[],h=false,k=true;if(0===d.length){for(g=0;g<this.offers.length;g++){if(!BX.util.in_array(this.offers[g].TREE[f],c)){c[c.length]=this.offers[g].TREE[f]}}h=true}else{for(g=0;g<this.offers.length;g++){k=true;for(e in d){if(d[e]!==this.offers[g].TREE[e]){k=false;break}}if(k){if(!BX.util.in_array(this.offers[g].TREE[f],c)){c[c.length]=this.offers[g].TREE[f]}h=true}}}return(h?c:false)},getCanBuy:function(c){var e,d,f=false,g=true;for(e=0;e<this.offers.length;e++){g=true;for(d in c){if(c[d]!==this.offers[e].TREE[d]){g=false;break}}if(g){if(this.offers[e].CAN_BUY){f=true;break}}}return f},setCurrent:function(){var h,g=0,c=[],k="",f=false,e={},d=[],l=this.offers[this.offerNum].TREE;for(h=0;h<this.treeProps.length;h++){k="PROP_"+this.treeProps[h].ID;f=this.getRowValues(e,k);if(!f){break}if(BX.util.in_array(l[k],f)){e[k]=l[k]}else{e[k]=f[0];this.offerNum=0}if(this.showAbsent){c=[];d=[];d=BX.clone(e,true);for(g=0;g<f.length;g++){d[k]=f[g];if(this.getCanBuy(d)){c[c.length]=f[g]}}}else{c=f}this.updateRow(h,e[k],f,c)}this.selectedValues=e;this.changeInfo()},changeInfo:function(){var e,d,c=-1,f=true,g;for(e=0;e<this.offers.length;e++){f=true;for(d in this.selectedValues){if(this.selectedValues[d]!==this.offers[e].TREE[d]){f=false;break}}if(f){c=e;break}}if(c>-1){if(parseInt(this.offers[c].MORE_PHOTO_COUNT)>1&&this.obPictSlider){if(this.obPict){this.obPict.style.display="none"}if(this.obSecondPict){this.obSecondPict.style.display="none"}BX.cleanNode(this.obPictSlider);for(e in this.offers[c].MORE_PHOTO){if(this.offers[c].MORE_PHOTO.hasOwnProperty(e)){this.obPictSlider.appendChild(BX.create("SPAN",{props:{className:"product-item-image-slide item"+(e==0?" active":"")},style:{backgroundImage:"url('"+this.offers[c].MORE_PHOTO[e].SRC+"')"}}))}}if(this.obPictSliderIndicator){BX.cleanNode(this.obPictSliderIndicator);for(e in this.offers[c].MORE_PHOTO){if(this.offers[c].MORE_PHOTO.hasOwnProperty(e)){this.obPictSliderIndicator.appendChild(BX.create("DIV",{attrs:{"data-go-to":e},props:{className:"product-item-image-slider-control"+(e==0?" active":"")}}));this.obPictSliderIndicator.appendChild(document.createTextNode(" "))}}this.obPictSliderIndicator.style.display=""}if(this.obPictSliderProgressBar){this.obPictSliderProgressBar.style.display=""}this.obPictSlider.style.display="";this.initializeSlider()}else{if(this.obPictSlider){this.obPictSlider.style.display="none"}if(this.obPictSliderIndicator){this.obPictSliderIndicator.style.display="none"}if(this.obPictSliderProgressBar){this.obPictSliderProgressBar.style.display="none"}if(this.obPict){if(this.offers[c].PREVIEW_PICTURE){BX.adjust(this.obPict,{style:{backgroundImage:"url('"+this.offers[c].PREVIEW_PICTURE.SRC+"')"}})}else{BX.adjust(this.obPict,{style:{backgroundImage:"url('"+this.defaultPict.pict.SRC+"')"}})}this.obPict.style.display=""}if(this.secondPict&&this.obSecondPict){if(this.offers[c].PREVIEW_PICTURE_SECOND){BX.adjust(this.obSecondPict,{style:{backgroundImage:"url('"+this.offers[c].PREVIEW_PICTURE_SECOND.SRC+"')"}})}else{if(this.offers[c].PREVIEW_PICTURE.SRC){BX.adjust(this.obSecondPict,{style:{backgroundImage:"url('"+this.offers[c].PREVIEW_PICTURE.SRC+"')"}})}else{if(this.defaultPict.secondPict){BX.adjust(this.obSecondPict,{style:{backgroundImage:"url('"+this.defaultPict.secondPict.SRC+"')"}})}else{BX.adjust(this.obSecondPict,{style:{backgroundImage:"url('"+this.defaultPict.pict.SRC+"')"}})}}}this.obSecondPict.style.display=""}}if(this.showSkuProps&&this.obSkuProps){if(this.offers[c].DISPLAY_PROPERTIES.length){BX.adjust(this.obSkuProps,{style:{display:""},html:this.offers[c].DISPLAY_PROPERTIES})}else{BX.adjust(this.obSkuProps,{style:{display:"none"},html:""})}}this.quantitySet(c);this.setPrice();this.setCompared(this.offers[c].COMPARED);this.offerNum=c}},checkPriceRange:function(g){if(typeof g==="undefined"||this.currentPriceMode!="Q"){return}var d,f=false;for(var e in this.currentQuantityRanges){if(this.currentQuantityRanges.hasOwnProperty(e)){d=this.currentQuantityRanges[e];if(parseInt(g)>=parseInt(d.SORT_FROM)&&(d.SORT_TO=="INF"||parseInt(g)<=parseInt(d.SORT_TO))){f=true;this.currentQuantityRangeSelected=d.HASH;break}}}if(!f&&(d=this.getMinPriceRange())){this.currentQuantityRangeSelected=d.HASH}for(var c in this.currentPrices){if(this.currentPrices.hasOwnProperty(c)){if(this.currentPrices[c].QUANTITY_HASH==this.currentQuantityRangeSelected){this.currentPriceSelected=c;break}}}},getMinPriceRange:function(){var c;for(var d in this.currentQuantityRanges){if(this.currentQuantityRanges.hasOwnProperty(d)){if(!c||parseInt(this.currentQuantityRanges[d].SORT_FROM)<parseInt(c.SORT_FROM)){c=this.currentQuantityRanges[d]}}}return c},checkQuantityControls:function(){if(!this.obQuantity){return}var d=this.checkQuantity&&parseFloat(this.obQuantity.value)+this.stepQuantity>this.maxQuantity,c=parseFloat(this.obQuantity.value)-this.stepQuantity<this.minQuantity;if(d){BX.addClass(this.obQuantityUp,"product-item-amount-field-btn-disabled")}else{if(BX.hasClass(this.obQuantityUp,"product-item-amount-field-btn-disabled")){BX.removeClass(this.obQuantityUp,"product-item-amount-field-btn-disabled")}}if(c){BX.addClass(this.obQuantityDown,"product-item-amount-field-btn-disabled")}else{if(BX.hasClass(this.obQuantityDown,"product-item-amount-field-btn-disabled")){BX.removeClass(this.obQuantityDown,"product-item-amount-field-btn-disabled")}}if(d&&c){this.obQuantity.setAttribute("disabled","disabled")}else{this.obQuantity.removeAttribute("disabled")}},setPrice:function(){var d,c;if(this.obQuantity){this.checkPriceRange(this.obQuantity.value)}this.checkQuantityControls();c=this.currentPrices[this.currentPriceSelected];if(this.obPrice){if(c){BX.adjust(this.obPrice,{html:BX.Currency.currencyFormat(c.RATIO_PRICE,c.CURRENCY,true)})}else{BX.adjust(this.obPrice,{html:""})}if(this.showOldPrice&&this.obPriceOld){if(c&&c.RATIO_PRICE!==c.RATIO_BASE_PRICE){BX.adjust(this.obPriceOld,{style:{display:""},html:BX.Currency.currencyFormat(c.RATIO_BASE_PRICE,c.CURRENCY,true)})}else{BX.adjust(this.obPriceOld,{style:{display:"none"},html:""})}}if(this.obPriceTotal){if(c&&this.obQuantity&&this.obQuantity.value!=this.stepQuantity){BX.adjust(this.obPriceTotal,{html:BX.message("PRICE_TOTAL_PREFIX")+" <strong>"+BX.Currency.currencyFormat(c.PRICE*this.obQuantity.value,c.CURRENCY,true)+"</strong>",style:{display:""}})}else{BX.adjust(this.obPriceTotal,{html:"",style:{display:"none"}})}}if(this.showPercent){if(c&&parseInt(c.PERCENT)>0){d={style:{display:""},html:-c.PERCENT+"%"}}else{d={style:{display:"none"},html:""}}if(this.obDscPerc){BX.adjust(this.obDscPerc,d)}if(this.obSecondDscPerc){BX.adjust(this.obSecondDscPerc,d)}}}},compare:function(e){var g=this.obCompare.querySelector('[data-entity="compare-checkbox"]'),h=BX.getEventTarget(e),d=true;if(g){d=h===g?g.checked:!g.checked}var c=d?this.compareData.compareUrl:this.compareData.compareDeleteUrl,f;if(c){if(h!==g){BX.PreventDefault(e);this.setCompared(d)}switch(this.productType){case 0:case 1:case 2:f=c.replace("#ID#",this.product.id.toString());break;case 3:f=c.replace("#ID#",this.offers[this.offerNum].ID);break}BX.ajax({method:"POST",dataType:d?"json":"html",url:f+(f.indexOf("?")!==-1?"&":"?")+"ajax_action=Y",onsuccess:d?BX.proxy(this.compareResult,this):BX.proxy(this.compareDeleteResult,this)})}},compareResult:function(c){var d,e;if(this.obPopupWin){this.obPopupWin.close()}if(!BX.type.isPlainObject(c)){return}this.initPopupWindow();if(this.offers.length>0){this.offers[this.offerNum].COMPARED=c.STATUS==="OK"}if(c.STATUS==="OK"){BX.onCustomEvent("OnCompareChange");d='<div style="width: 100%; margin: 0; text-align: center;"><p>'+BX.message("COMPARE_MESSAGE_OK")+"</p></div>";if(this.showClosePopup){e=[new a({text:BX.message("BTN_MESSAGE_COMPARE_REDIRECT"),events:{click:BX.delegate(this.compareRedirect,this)},style:{marginRight:"10px"}}),new a({text:BX.message("BTN_MESSAGE_CLOSE_POPUP"),events:{click:BX.delegate(this.obPopupWin.close,this.obPopupWin)}})]}else{e=[new a({text:BX.message("BTN_MESSAGE_COMPARE_REDIRECT"),events:{click:BX.delegate(this.compareRedirect,this)}})]}}else{d='<div style="width: 100%; margin: 0; text-align: center;"><p>'+(c.MESSAGE?c.MESSAGE:BX.message("COMPARE_UNKNOWN_ERROR"))+"</p></div>";e=[new a({text:BX.message("BTN_MESSAGE_CLOSE"),events:{click:BX.delegate(this.obPopupWin.close,this.obPopupWin)}})]}this.obPopupWin.setTitleBar(BX.message("COMPARE_TITLE"));this.obPopupWin.setContent(d);this.obPopupWin.setButtons(e);this.obPopupWin.show()},compareDeleteResult:function(){BX.onCustomEvent("OnCompareChange");if(this.offers&&this.offers.length){this.offers[this.offerNum].COMPARED=false}},setCompared:function(d){if(!this.obCompare){return}var c=this.obCompare.querySelector('[data-entity="compare-checkbox"]');if(c){c.checked=d}},setCompareInfo:function(c){if(!BX.type.isArray(c)){return}for(var d in this.offers){if(this.offers.hasOwnProperty(d)){this.offers[d].COMPARED=BX.util.in_array(this.offers[d].ID,c)}}},compareRedirect:function(){if(this.compareData.comparePath){location.href=this.compareData.comparePath}else{this.obPopupWin.close()}},checkDeletedCompare:function(d){switch(this.productType){case 0:case 1:case 2:if(this.product.id==d){this.setCompared(false)}break;case 3:var c=this.offers.length;while(c--){if(this.offers[c].ID==d){this.offers[c].COMPARED=false;if(this.offerNum==c){this.setCompared(false)}break}}}},initBasketUrl:function(){this.basketUrl=(this.basketMode==="ADD"?this.basketData.add_url:this.basketData.buy_url);switch(this.productType){case 1:case 2:this.basketUrl=this.basketUrl.replace("#ID#",this.product.id.toString());break;case 3:this.basketUrl=this.basketUrl.replace("#ID#",this.offers[this.offerNum].ID);break}this.basketParams={ajax_basket:"Y"};if(this.showQuantity){this.basketParams[this.basketData.quantity]=this.obQuantity.value}if(this.basketData.sku_props){this.basketParams[this.basketData.sku_props_var]=this.basketData.sku_props}},fillBasketProps:function(){if(!this.visual.BASKET_PROP_DIV){return}var c=0,f=null,e=false,d=null;if(this.basketData.useProps&&!this.basketData.emptyProps){if(this.obPopupWin&&this.obPopupWin.contentContainer){d=this.obPopupWin.contentContainer}}else{d=BX(this.visual.BASKET_PROP_DIV)}if(d){f=d.getElementsByTagName("select");if(f&&f.length){for(c=0;c<f.length;c++){if(!f[c].disabled){switch(f[c].type.toLowerCase()){case"select-one":this.basketParams[f[c].name]=f[c].value;e=true;break;default:break}}}}f=d.getElementsByTagName("input");if(f&&f.length){for(c=0;c<f.length;c++){if(!f[c].disabled){switch(f[c].type.toLowerCase()){case"hidden":this.basketParams[f[c].name]=f[c].value;e=true;break;case"radio":if(f[c].checked){this.basketParams[f[c].name]=f[c].value;e=true}break;default:break}}}}}if(!e){this.basketParams[this.basketData.props]=[];this.basketParams[this.basketData.props][0]=0}},add2Basket:function(){this.basketMode="ADD";this.basket()},buyBasket:function(){this.basketMode="BUY";this.basket()},sendToBasket:function(){if(!this.canBuy){return}if(this.product&&this.product.id&&this.bigData){this.rememberProductRecommendation()}this.initBasketUrl();this.fillBasketProps();BX.ajax({method:"POST",dataType:"json",url:this.basketUrl,data:this.basketParams,onsuccess:BX.proxy(this.basketResult,this)})},basket:function(){var c="";if(!this.canBuy){return}switch(this.productType){case 1:case 2:if(this.basketData.useProps&&!this.basketData.emptyProps){this.initPopupWindow();this.obPopupWin.setTitleBar(BX.message("TITLE_BASKET_PROPS"));if(BX(this.visual.BASKET_PROP_DIV)){c=BX(this.visual.BASKET_PROP_DIV).innerHTML}this.obPopupWin.setContent(c);this.obPopupWin.setButtons([new a({text:BX.message("BTN_MESSAGE_SEND_PROPS"),events:{click:BX.delegate(this.sendToBasket,this)}})]);this.obPopupWin.show()}else{this.sendToBasket()}break;case 3:this.sendToBasket();break}},basketResult:function(e){var d="",f="",g,c=[];if(this.obPopupWin){this.obPopupWin.close()}if(!BX.type.isPlainObject(e)){return}g=e.STATUS==="OK";if(g){this.setAnalyticsDataLayer("addToCart")}if(g&&this.basketAction==="BUY"){this.basketRedirect()}else{this.initPopupWindow();if(g){BX.onCustomEvent("OnBasketChange");if(BX.findParent(this.obProduct,{className:"bx_sale_gift_main_products"},10)){BX.onCustomEvent("onAddToBasketMainProduct",[this])}switch(this.productType){case 1:case 2:f=this.product.pict.SRC;break;case 3:f=(this.offers[this.offerNum].PREVIEW_PICTURE?this.offers[this.offerNum].PREVIEW_PICTURE.SRC:this.defaultPict.pict.SRC);break}d='<div style="width: 100%; margin: 0; text-align: center;"><img src="'+f+'" height="130" style="max-height:130px"><p>'+this.product.name+"</p></div>";if(this.showClosePopup){c=[new a({text:BX.message("BTN_MESSAGE_BASKET_REDIRECT"),events:{click:BX.delegate(this.basketRedirect,this)},style:{marginRight:"10px"}}),new a({text:BX.message("BTN_MESSAGE_CLOSE_POPUP"),events:{click:BX.delegate(this.obPopupWin.close,this.obPopupWin)}})]}else{c=[new a({text:BX.message("BTN_MESSAGE_BASKET_REDIRECT"),events:{click:BX.delegate(this.basketRedirect,this)}})]}}else{d='<div style="width: 100%; margin: 0; text-align: center;"><p>'+(e.MESSAGE?e.MESSAGE:BX.message("BASKET_UNKNOWN_ERROR"))+"</p></div>";c=[new a({text:BX.message("BTN_MESSAGE_CLOSE"),events:{click:BX.delegate(this.obPopupWin.close,this.obPopupWin)}})]}this.obPopupWin.setTitleBar(g?BX.message("TITLE_SUCCESSFUL"):BX.message("TITLE_ERROR"));this.obPopupWin.setContent(d);this.obPopupWin.setButtons(c);this.obPopupWin.show()}},basketRedirect:function(){location.href=(this.basketData.basketUrl?this.basketData.basketUrl:BX.message("BASKET_URL"))},initPopupWindow:function(){if(this.obPopupWin){return}this.obPopupWin=BX.PopupWindowManager.create("CatalogSectionBasket_"+this.visual.ID,null,{autoHide:true,offsetLeft:0,offsetTop:0,overlay:true,closeByEsc:true,titleBar:true,closeIcon:true,contentColor:"white",className:this.templateTheme?"bx-"+this.templateTheme:""})}}})(window);
/* End */
;; /* /bitrix/components/bitrix/search.suggest.input/templates/.default/script.js?168313605112503*/
; /* /local/templates/coferrier/components/bitrix/catalog.section/.default/script.min.js?16871840335521*/
; /* /local/templates/coferrier/components/bitrix/catalog.item/item/script.min.js?168733976741278*/


; /* Start:"a:4:{s:4:"full";s:77:"/local/components/custom/basket/templates/.default/script.min.js?168734153323";s:6:"source";s:60:"/local/components/custom/basket/templates/.default/script.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
BX.ready(function(){});
/* End */
;; /* /local/components/custom/basket/templates/.default/script.min.js?168734153323*/

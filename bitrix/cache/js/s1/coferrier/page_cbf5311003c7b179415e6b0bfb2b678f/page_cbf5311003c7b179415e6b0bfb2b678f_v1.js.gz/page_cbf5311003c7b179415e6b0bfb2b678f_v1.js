
; /* Start:"a:4:{s:4:"full";s:79:"/local/components/custom/profile/templates/.default/script.min.js?1686145500126";s:6:"source";s:61:"/local/components/custom/profile/templates/.default/script.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
BX.ready(function(){document.getElementById("profile-change-btn").addEventListener("click",function(){console.log("qwer")})});
/* End */
;; /* /local/components/custom/profile/templates/.default/script.min.js?1686145500126*/
